// Banco de dados em memória para demonstração
// Quando MongoDB estiver disponível, remova este arquivo e use o db.js original

const db = {
  products: [],
  employees: [],
  services: [],
  orders: [],
  nextIds: {
    products: 1,
    employees: 1,
    services: 1,
    orders: 1,
  },
};

// Função para gerar IDs simulados
function generateId(type) {
  const id = db.nextIds[type]++;
  return id.toString();
}

// Funções auxiliares
const dbMemory = {
  // Produtos
  createProduct: (data) => {
    const product = {
      _id: generateId('products'),
      ...data,
      dateEntry: new Date(),
    };
    db.products.push(product);
    return product;
  },
  getProducts: () => db.products,
  getProductById: (id) => db.products.find(p => p._id === id),
  updateProduct: (id, data) => {
    const idx = db.products.findIndex(p => p._id === id);
    if (idx !== -1) {
      db.products[idx] = { ...db.products[idx], ...data };
      return db.products[idx];
    }
    return null;
  },
  deleteProduct: (id) => {
    const idx = db.products.findIndex(p => p._id === id);
    if (idx !== -1) {
      db.products.splice(idx, 1);
      return true;
    }
    return false;
  },

  // Funcionários
  createEmployee: (data) => {
    const employee = {
      _id: generateId('employees'),
      ...data,
      hireDate: new Date(),
    };
    db.employees.push(employee);
    return employee;
  },
  getEmployees: () => db.employees,
  getEmployeeById: (id) => db.employees.find(e => e._id === id),
  updateEmployee: (id, data) => {
    const idx = db.employees.findIndex(e => e._id === id);
    if (idx !== -1) {
      db.employees[idx] = { ...db.employees[idx], ...data };
      return db.employees[idx];
    }
    return null;
  },
  deleteEmployee: (id) => {
    const idx = db.employees.findIndex(e => e._id === id);
    if (idx !== -1) {
      db.employees.splice(idx, 1);
      return true;
    }
    return false;
  },

  // Serviços
  createService: (data) => {
    const service = {
      _id: generateId('services'),
      ...data,
    };
    db.services.push(service);
    return service;
  },
  getServices: () => db.services,
  getServiceById: (id) => db.services.find(s => s._id === id),
  updateService: (id, data) => {
    const idx = db.services.findIndex(s => s._id === id);
    if (idx !== -1) {
      db.services[idx] = { ...db.services[idx], ...data };
      return db.services[idx];
    }
    return null;
  },
  deleteService: (id) => {
    const idx = db.services.findIndex(s => s._id === id);
    if (idx !== -1) {
      db.services.splice(idx, 1);
      return true;
    }
    return false;
  },

  // Pedidos
  createOrder: (data) => {
    const order = {
      _id: generateId('orders'),
      ...data,
      date: new Date(),
    };
    db.orders.push(order);
    return order;
  },
  getOrders: () => db.orders,
  getOrderById: (id) => db.orders.find(o => o._id === id),
  updateOrder: (id, data) => {
    const idx = db.orders.findIndex(o => o._id === id);
    if (idx !== -1) {
      db.orders[idx] = { ...db.orders[idx], ...data };
      return db.orders[idx];
    }
    return null;
  },
  deleteOrder: (id) => {
    const idx = db.orders.findIndex(o => o._id === id);
    if (idx !== -1) {
      db.orders.splice(idx, 1);
      return true;
    }
    return false;
  },
};

module.exports = dbMemory;
