const Employee = require('../models/employee');

exports.createEmployee = async (req, res, next) => {
  try {
    const emp = await Employee.create(req.body);
    res.status(201).json(emp);
  } catch (err) { next(err); }
};

exports.getEmployees = async (req, res, next) => {
  try {
    const list = await Employee.find();
    res.json(list);
  } catch (err) { next(err); }
};

exports.getEmployee = async (req, res, next) => {
  try {
    const emp = await Employee.findById(req.params.id);
    if (!emp) return res.status(404).json({ message: 'Funcionário não encontrado' });
    res.json(emp);
  } catch (err) { next(err); }
};

exports.updateEmployee = async (req, res, next) => {
  try {
    const emp = await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(emp);
  } catch (err) { next(err); }
};

exports.deleteEmployee = async (req, res, next) => {
  try {
    await Employee.findByIdAndDelete(req.params.id);
    res.json({ message: 'Funcionário deletado' });
  } catch (err) { next(err); }
};