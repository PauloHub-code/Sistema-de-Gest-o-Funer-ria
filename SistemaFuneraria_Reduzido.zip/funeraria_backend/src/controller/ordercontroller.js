const Order = require('../models/order');
const Product = require('../models/product');

// cria ordem, calcula total e (opcionalmente) atualiza estoque quando status muda para 'concluida'
exports.createOrder = async (req, res, next) => {
  try {
    const { clientName, products = [], services = [], employee } = req.body;

    // popular preços dos produtos/serviços se não enviados
    const populatedProducts = await Promise.all(products.map(async p => {
      const prod = await Product.findById(p.product);
      if (!prod) throw new Error(`Produto não encontrado: ${p.product}`);
      return {
        product: prod._id,
        quantity: p.quantity || 1,
        price: p.price != null ? p.price : prod.sellPrice
      };
    }));

    const populatedServices = services.map(s => ({
      service: s.service,
      price: s.price || 0
    }));

    const totalFromProducts = populatedProducts.reduce((sum, p) => sum + (p.price * p.quantity), 0);
    const totalFromServices = populatedServices.reduce((sum, s) => sum + (s.price || 0), 0);
    const total = totalFromProducts + totalFromServices;

    const order = await Order.create({ clientName, products: populatedProducts, services: populatedServices, employee, totalPrice: total });

    res.status(201).json(order);
  } catch (err) { next(err); }
};

exports.getOrders = async (req, res, next) => {
  try {
    const list = await Order.find()
      .populate('products.product')
      .populate('services.service')
      .populate('employee');
    res.json(list);
  } catch (err) { next(err); }
};

exports.getOrder = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('products.product')
      .populate('services.service')
      .populate('employee');
    if (!order) return res.status(404).json({ message: 'Ordem não encontrada' });
    res.json(order);
  } catch (err) { next(err); }
};

// atualizar ordem; se status mudar para 'concluida' subtrai do estoque
exports.updateOrder = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'Ordem não encontrada' });

    const prevStatus = order.status;
    Object.assign(order, req.body);

    // recalc total se produtos/serviços foram alterados
    if (req.body.products || req.body.services) {
      const prods = await Promise.all((order.products || []).map(async p => {
        const prod = await Product.findById(p.product);
        return { product: prod._id, quantity: p.quantity, price: p.price != null ? p.price : prod.sellPrice };
      }));
      const servs = (order.services || []).map(s => ({ service: s.service, price: s.price || 0 }));
      const totalP = prods.reduce((s, p) => s + (p.price * p.quantity), 0);
      const totalS = servs.reduce((s, sv) => s + (sv.price || 0), 0);
      order.totalPrice = totalP + totalS;
      order.products = prods;
      order.services = servs;
    }

    // se status mudou para 'concluida' e antes não era concluida, decrementar estoque
    if (prevStatus !== 'concluida' && order.status === 'concluida') {
      for (const item of order.products) {
        const prod = await Product.findById(item.product);
        if (!prod) continue;
        prod.quantity = Math.max(0, prod.quantity - item.quantity);
        await prod.save();
      }
    }

    await order.save();
    const updated = await Order.findById(order._id).populate('products.product').populate('services.service').populate('employee');
    res.json(updated);
  } catch (err) { next(err); }
};

exports.deleteOrder = async (req, res, next) => {
  try {
    await Order.findByIdAndDelete(req.params.id);
    res.json({ message: 'Ordem deletada' });
  } catch (err) { next(err); }
};