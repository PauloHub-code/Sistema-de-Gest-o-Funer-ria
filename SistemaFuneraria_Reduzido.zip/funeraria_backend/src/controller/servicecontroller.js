const Service = require('../models/service');

exports.createService = async (req, res, next) => {
  try {
    const s = await Service.create(req.body);
    res.status(201).json(s);
  } catch (err) { next(err); }
};

exports.getServices = async (req, res, next) => {
  try {
    const list = await Service.find();
    res.json(list);
  } catch (err) { next(err); }
};

exports.getService = async (req, res, next) => {
  try {
    const s = await Service.findById(req.params.id);
    if (!s) return res.status(404).json({ message: 'Serviço não encontrado' });
    res.json(s);
  } catch (err) { next(err); }
};

exports.updateService = async (req, res, next) => {
  try {
    const s = await Service.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(s);
  } catch (err) { next(err); }
};

exports.deleteService = async (req, res, next) => {
  try {
    await Service.findByIdAndDelete(req.params.id);
    res.json({ message: 'Serviço deletado' });
  } catch (err) { next(err); }
};