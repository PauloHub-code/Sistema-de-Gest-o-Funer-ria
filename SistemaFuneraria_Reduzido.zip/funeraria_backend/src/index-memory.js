require('dotenv').config();
const express = require('express');
const cors = require('cors');
const dbMemory = require('./config/db-memory');

// Importar controllers
const ProductController = require('./controller/productcontroller');
const EmployeeController = require('./controller/employeecontroller');
const ServiceController = require('./controller/servicecontroller');
const OrderController = require('./controller/ordercontroller');

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Rota de teste
app.get('/', (req, res) => res.send('API Funerária funcionando'));

// Rotas de Produtos
app.post('/api/products', (req, res) => {
  try {
    const product = dbMemory.createProduct(req.body);
    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/products', (req, res) => {
  try {
    const products = dbMemory.getProducts();
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/products/:id', (req, res) => {
  try {
    const product = dbMemory.getProductById(req.params.id);
    if (!product) return res.status(404).json({ error: 'Produto não encontrado' });
    res.json(product);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/products/:id', (req, res) => {
  try {
    const product = dbMemory.updateProduct(req.params.id, req.body);
    if (!product) return res.status(404).json({ error: 'Produto não encontrado' });
    res.json(product);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/products/:id', (req, res) => {
  try {
    const success = dbMemory.deleteProduct(req.params.id);
    if (!success) return res.status(404).json({ error: 'Produto não encontrado' });
    res.json({ message: 'Produto deletado com sucesso' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rotas de Funcionários
app.post('/api/employees', (req, res) => {
  try {
    const employee = dbMemory.createEmployee(req.body);
    res.status(201).json(employee);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/employees', (req, res) => {
  try {
    const employees = dbMemory.getEmployees();
    res.json(employees);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/employees/:id', (req, res) => {
  try {
    const employee = dbMemory.getEmployeeById(req.params.id);
    if (!employee) return res.status(404).json({ error: 'Funcionário não encontrado' });
    res.json(employee);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/employees/:id', (req, res) => {
  try {
    const employee = dbMemory.updateEmployee(req.params.id, req.body);
    if (!employee) return res.status(404).json({ error: 'Funcionário não encontrado' });
    res.json(employee);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/employees/:id', (req, res) => {
  try {
    const success = dbMemory.deleteEmployee(req.params.id);
    if (!success) return res.status(404).json({ error: 'Funcionário não encontrado' });
    res.json({ message: 'Funcionário deletado com sucesso' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rotas de Serviços
app.post('/api/services', (req, res) => {
  try {
    const service = dbMemory.createService(req.body);
    res.status(201).json(service);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/services', (req, res) => {
  try {
    const services = dbMemory.getServices();
    res.json(services);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/services/:id', (req, res) => {
  try {
    const service = dbMemory.getServiceById(req.params.id);
    if (!service) return res.status(404).json({ error: 'Serviço não encontrado' });
    res.json(service);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/services/:id', (req, res) => {
  try {
    const service = dbMemory.updateService(req.params.id, req.body);
    if (!service) return res.status(404).json({ error: 'Serviço não encontrado' });
    res.json(service);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/services/:id', (req, res) => {
  try {
    const success = dbMemory.deleteService(req.params.id);
    if (!success) return res.status(404).json({ error: 'Serviço não encontrado' });
    res.json({ message: 'Serviço deletado com sucesso' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rotas de Pedidos
app.post('/api/orders', (req, res) => {
  try {
    const order = dbMemory.createOrder(req.body);
    res.status(201).json(order);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.get('/api/orders', (req, res) => {
  try {
    const orders = dbMemory.getOrders();
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/orders/:id', (req, res) => {
  try {
    const order = dbMemory.getOrderById(req.params.id);
    if (!order) return res.status(404).json({ error: 'Pedido não encontrado' });
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/orders/:id', (req, res) => {
  try {
    const order = dbMemory.updateOrder(req.params.id, req.body);
    if (!order) return res.status(404).json({ error: 'Pedido não encontrado' });
    res.json(order);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/orders/:id', (req, res) => {
  try {
    const success = dbMemory.deleteOrder(req.params.id);
    if (!success) return res.status(404).json({ error: 'Pedido não encontrado' });
    res.json({ message: 'Pedido deletado com sucesso' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Tratamento de erros
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Erro interno do servidor' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
