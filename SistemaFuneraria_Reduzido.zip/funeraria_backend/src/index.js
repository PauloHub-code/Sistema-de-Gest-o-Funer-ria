require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const productRoutes = require('./routes/productroutes');
const employeeRoutes = require('./routes/employeeroutes');
const serviceRoutes = require('./routes/serviceroutes');
const orderRoutes = require('./routes/orderroutes');
const errorHandler = require('./middleware/errorhandler');

const app = express();
connectDB();

// Configurar CORS para permitir requisições do frontend
app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000', 'http://127.0.0.1:5173', 'http://localhost:3002'],
  credentials: true
}));

app.use(express.json());

app.get('/', (req, res) => res.send('API Funerária funcionando'));

app.use('/api/products', productRoutes);
app.use('/api/employees', employeeRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/orders', orderRoutes);

app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
