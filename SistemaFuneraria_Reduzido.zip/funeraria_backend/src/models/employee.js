const mongoose = require('mongoose');

const EmployeeSchema = new mongoose.Schema({
  name: { type: String, required: true },
  role: { type: String, default: '' },
  salary: { type: Number, default: 0 },
  workSchedule: { type: String, default: '' },
  hireDate: { type: Date, default: Date.now },
  status: { type: String, enum: ['ativo', 'inativo'], default: 'ativo' },
});

module.exports = mongoose.model('Employee', EmployeeSchema);