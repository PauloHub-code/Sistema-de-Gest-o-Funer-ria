const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
  clientName: { type: String, required: true },
  products: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: { type: Number, default: 1 },
    price: { type: Number, default: 0 },
  }],
  services: [{
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service' },
    price: { type: Number, default: 0 }
  }],
  employee: { type: mongoose.Schema.Types.ObjectId, ref: 'Employee' },
  date: { type: Date, default: Date.now },
  totalPrice: { type: Number, default: 0 },
  status: { type: String, enum: ['aberta', 'concluida', 'cancelada'], default: 'aberta' }
});

module.exports = mongoose.model('Order', OrderSchema);