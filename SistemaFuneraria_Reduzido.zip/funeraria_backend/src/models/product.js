const mongoose = require('mongoose');

const ProductSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, default: '' },
  quantity: { type: Number, default: 0 },
  costPrice: { type: Number, default: 0 },
  sellPrice: { type: Number, default: 0 },
  supplier: { type: String, default: '' },
  dateEntry: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Product', ProductSchema);