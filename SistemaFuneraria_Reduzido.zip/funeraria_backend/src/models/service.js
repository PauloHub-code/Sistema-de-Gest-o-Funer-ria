const mongoose = require('mongoose');

const ServiceSchema = new mongoose.Schema({
  name: { type: String, required: true },
  price: { type: Number, default: 0 },
  estimatedTime: { type: String, default: '' },
  responsibleRole: { type: String, default: '' },
});

module.exports = mongoose.model('Service', ServiceSchema);