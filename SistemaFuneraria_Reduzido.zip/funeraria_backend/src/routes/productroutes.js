const express = require("express");
const router = express.Router();

// Caminho corrigido: pasta é "controller" e arquivo é minúsculo
const ProductController = require("../controller/productcontroller");

// Rotas de produtos
router.post("/", ProductController.createProduct);
router.get("/", ProductController.getProducts);           // nome corrigido
router.get("/:id", ProductController.getProduct);         // nome corrigido
router.put("/:id", ProductController.updateProduct);
router.delete("/:id", ProductController.deleteProduct);

module.exports = router;
