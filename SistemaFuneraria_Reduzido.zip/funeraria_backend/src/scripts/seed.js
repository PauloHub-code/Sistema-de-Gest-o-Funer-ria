require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const Product = require('../models/product');
const Employee = require('../models/employee');
const Service = require('../models/service');

(async () => {
  try {
    await connectDB();

    // limpar coleções
    await Product.deleteMany();
    await Employee.deleteMany();
    await Service.deleteMany();

    // criar produtos
    const products = await Product.create([
      { name: 'Caixão Simples', category: 'caixão', quantity: 5, sellPrice: 1200 },
      { name: 'Corpo de Flores', category: 'flores', quantity: 20, sellPrice: 200 },
      { name: 'Vela Grande', category: 'velas', quantity: 50, sellPrice: 10 }
    ]);

    // criar funcionários
    const employees = await Employee.create([
      { name: 'João Silva', role: 'Atendente', salary: 1500 },
      { name: 'Maria Souza', role: 'Motorista', salary: 1600 }
    ]);

    // criar serviços
    const services = await Service.create([
      { name: 'Translado (cidade)', price: 300, estimatedTime: '2h' },
      { name: 'Preparação do corpo', price: 500, estimatedTime: '3h' }
    ]);

    console.log('Seed finalizado. Produtos:', products.length, 'Funcionários:', employees.length, 'Serviços:', services.length);
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();