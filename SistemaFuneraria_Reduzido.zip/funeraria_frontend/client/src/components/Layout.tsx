import { Link } from 'wouter';
import { Package, Users, Briefcase, ShoppingCart, Menu, X } from 'lucide-react';
import { useState } from 'react';

interface LayoutProps {
  children: React.ReactNode;
  currentPage?: string;
}

export default function Layout({ children, currentPage }: LayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const navItems = [
    { href: '/', label: 'Dashboard', icon: ShoppingCart },
    { href: '/products', label: 'Produtos', icon: Package },
    { href: '/employees', label: 'Funcionários', icon: Users },
    { href: '/services', label: 'Serviços', icon: Briefcase },
    { href: '/orders', label: 'Pedidos', icon: ShoppingCart },
  ];

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? 'w-64' : 'w-0'
        } bg-sidebar text-sidebar-foreground transition-all duration-300 overflow-hidden flex flex-col border-r-2 border-sidebar-accent`}
      >
        {/* Header do Sidebar */}
        <div className="p-6 border-b-2 border-sidebar-accent">
          <h1 className="display text-xl font-bold text-sidebar-accent">
            Funerária
          </h1>
          <p className="text-sm text-sidebar-foreground/70 mt-1">Sistema de Gestão</p>
        </div>

        {/* Navegação */}
        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <a
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                    isActive
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground font-semibold'
                      : 'text-sidebar-foreground hover:bg-sidebar-primary/20'
                  }`}
                >
                  <Icon size={20} />
                  <span>{item.label}</span>
                </a>
              </Link>
            );
          })}
        </nav>

        {/* Footer do Sidebar */}
        <div className="p-4 border-t-2 border-sidebar-accent text-xs text-sidebar-foreground/60">
          <p>© 2024 Funerária CRUD</p>
          <p>Sistema de Gestão</p>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-card border-b-2 border-accent shadow-sm">
          <div className="flex items-center justify-between px-6 py-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
            >
              {sidebarOpen ? (
                <X size={24} className="text-foreground" />
              ) : (
                <Menu size={24} className="text-foreground" />
              )}
            </button>
            <h2 className="heading-lg text-primary">
              Sistema de Gestão Funerária
            </h2>
            <div className="w-10" />
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-background">
          <div className="p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
