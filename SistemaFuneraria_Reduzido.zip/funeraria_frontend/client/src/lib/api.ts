import axios from 'axios';

// Configurar a URL base da API
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Tipos de dados
export interface Product {
  _id?: string;
  name: string;
  category: string;
  quantity: number;
  costPrice: number;
  sellPrice: number;
  supplier: string;
  dateEntry?: Date;
}

export interface Employee {
  _id?: string;
  name: string;
  role: string;
  salary: number;
  workSchedule: string;
  hireDate?: Date;
  status: 'ativo' | 'inativo';
}

export interface Service {
  _id?: string;
  name: string;
  price: number;
  estimatedTime: string;
  responsibleRole: string;
}

export interface OrderItem {
  product?: string;
  service?: string;
  quantity?: number;
  price: number;
}

export interface Order {
  _id?: string;
  clientName: string;
  products: Array<{
    product: string;
    quantity: number;
    price: number;
  }>;
  services: Array<{
    service: string;
    price: number;
  }>;
  employee: string;
  date?: Date;
  totalPrice: number;
  status: 'aberta' | 'concluida' | 'cancelada';
}

// Funções para Produtos
export const productAPI = {
  getAll: () => api.get<Product[]>('/products'),
  getById: (id: string) => api.get<Product>(`/products/${id}`),
  create: (data: Product) => api.post<Product>('/products', data),
  update: (id: string, data: Product) => api.put<Product>(`/products/${id}`, data),
  delete: (id: string) => api.delete(`/products/${id}`),
};

// Funções para Funcionários
export const employeeAPI = {
  getAll: () => api.get<Employee[]>('/employees'),
  getById: (id: string) => api.get<Employee>(`/employees/${id}`),
  create: (data: Employee) => api.post<Employee>('/employees', data),
  update: (id: string, data: Employee) => api.put<Employee>(`/employees/${id}`, data),
  delete: (id: string) => api.delete(`/employees/${id}`),
};

// Funções para Serviços
export const serviceAPI = {
  getAll: () => api.get<Service[]>('/services'),
  getById: (id: string) => api.get<Service>(`/services/${id}`),
  create: (data: Service) => api.post<Service>('/services', data),
  update: (id: string, data: Service) => api.put<Service>(`/services/${id}`, data),
  delete: (id: string) => api.delete(`/services/${id}`),
};

// Funções para Pedidos
export const orderAPI = {
  getAll: () => api.get<Order[]>('/orders'),
  getById: (id: string) => api.get<Order>(`/orders/${id}`),
  create: (data: Order) => api.post<Order>('/orders', data),
  update: (id: string, data: Order) => api.put<Order>(`/orders/${id}`, data),
  delete: (id: string) => api.delete(`/orders/${id}`),
};

export default api;
