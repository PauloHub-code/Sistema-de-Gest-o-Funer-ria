import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { productAPI, employeeAPI, serviceAPI, orderAPI } from '@/lib/api';
import { Card } from '@/components/ui/card';
import { Package, Users, Briefcase, ShoppingCart } from 'lucide-react';

interface Stats {
  products: number;
  employees: number;
  services: number;
  orders: number;
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats>({
    products: 0,
    employees: 0,
    services: 0,
    orders: 0,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        const [productsRes, employeesRes, servicesRes, ordersRes] = await Promise.all([
          productAPI.getAll(),
          employeeAPI.getAll(),
          serviceAPI.getAll(),
          orderAPI.getAll(),
        ]);

        setStats({
          products: productsRes.data.length,
          employees: employeesRes.data.length,
          services: servicesRes.data.length,
          orders: ordersRes.data.length,
        });
      } catch (err) {
        setError('Erro ao carregar estatísticas');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const statCards = [
    {
      title: 'Produtos',
      value: stats.products,
      icon: Package,
      color: 'text-accent',
      bgColor: 'bg-accent/10',
    },
    {
      title: 'Funcionários',
      value: stats.employees,
      icon: Users,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      title: 'Serviços',
      value: stats.services,
      icon: Briefcase,
      color: 'text-secondary',
      bgColor: 'bg-secondary/10',
    },
    {
      title: 'Pedidos',
      value: stats.orders,
      icon: ShoppingCart,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
  ];

  return (
    <Layout currentPage="/">
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="display text-3xl font-bold text-primary">
            Bem-vindo ao Sistema
          </h1>
          <p className="text-foreground/70 mt-2">
            Gerencie produtos, funcionários, serviços e pedidos de forma eficiente
          </p>
        </div>

        {/* Stats Grid */}
        {error && (
          <div className="bg-destructive/10 border-2 border-destructive text-destructive p-4 rounded-lg">
            {error}
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="p-6 border-2 border-accent/30 animate-pulse">
                <div className="h-12 bg-muted rounded mb-4" />
                <div className="h-8 bg-muted rounded w-1/2" />
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {statCards.map((stat) => {
              const Icon = stat.icon;
              return (
                <Card
                  key={stat.title}
                  className="p-6 border-2 border-accent hover:border-accent/80 transition-all duration-300 hover:shadow-lg"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-foreground/70 text-sm font-medium">
                        {stat.title}
                      </p>
                      <p className="text-4xl font-bold text-primary mt-2">
                        {stat.value}
                      </p>
                    </div>
                    <div className={`${stat.bgColor} p-3 rounded-lg`}>
                      <Icon className={`${stat.color} w-6 h-6`} />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}

        {/* Info Section */}
        <Card className="p-8 border-2 border-accent/50 bg-white">
          <h2 className="heading-lg text-primary mb-4">Sobre o Sistema</h2>
          <div className="space-y-4 text-foreground/80 leading-relaxed">
            <p>
              Este é um sistema completo de gestão para funerárias, desenvolvido para
              facilitar o controle de produtos, funcionários, serviços e pedidos.
            </p>
            <p>
              Utilize o menu lateral para acessar cada seção e gerenciar seus dados de
              forma eficiente e organizada.
            </p>
            <p className="text-sm text-foreground/60 mt-6">
              Desenvolvido com React, Tailwind CSS e integração com API Node.js/Express
            </p>
          </div>
        </Card>
      </div>
    </Layout>
  );
}
