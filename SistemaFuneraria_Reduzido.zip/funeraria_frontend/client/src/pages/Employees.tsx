import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { Employee, employeeAPI } from '@/lib/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Trash2, Edit2, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function Employees() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Employee>({
    name: '',
    role: '',
    salary: 0,
    workSchedule: '',
    status: 'ativo',
  });

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      setLoading(true);
      const res = await employeeAPI.getAll();
      setEmployees(res.data);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar funcionários');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (employee?: Employee) => {
    if (employee) {
      setEditingId(employee._id || null);
      setFormData(employee);
    } else {
      setEditingId(null);
      setFormData({
        name: '',
        role: '',
        salary: 0,
        workSchedule: '',
        status: 'ativo',
      });
    }
    setOpenDialog(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await employeeAPI.update(editingId, formData);
        toast.success('Funcionário atualizado com sucesso');
      } else {
        await employeeAPI.create(formData);
        toast.success('Funcionário criado com sucesso');
      }
      setOpenDialog(false);
      fetchEmployees();
    } catch (err) {
      toast.error('Erro ao salvar funcionário');
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja deletar este funcionário?')) {
      try {
        await employeeAPI.delete(id);
        toast.success('Funcionário deletado com sucesso');
        fetchEmployees();
      } catch (err) {
        toast.error('Erro ao deletar funcionário');
        console.error(err);
      }
    }
  };

  return (
    <Layout currentPage="/employees">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="display text-3xl font-bold text-primary">Funcionários</h1>
            <p className="text-foreground/70 mt-1">Gerencie a equipe da funerária</p>
          </div>
          <Button
            onClick={() => handleOpenDialog()}
            className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
          >
            <Plus size={20} />
            Novo Funcionário
          </Button>
        </div>

        {error && (
          <div className="bg-destructive/10 border-2 border-destructive text-destructive p-4 rounded-lg">
            {error}
          </div>
        )}

        {/* Employees Table */}
        <Card className="border-2 border-accent/30 overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-foreground/60">Carregando funcionários...</div>
          ) : employees.length === 0 ? (
            <div className="p-8 text-center text-foreground/60">
              Nenhum funcionário cadastrado
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-primary text-primary-foreground">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Nome</th>
                    <th className="px-6 py-4 text-left font-semibold">Cargo</th>
                    <th className="px-6 py-4 text-right font-semibold">Salário</th>
                    <th className="px-6 py-4 text-left font-semibold">Horário</th>
                    <th className="px-6 py-4 text-center font-semibold">Status</th>
                    <th className="px-6 py-4 text-center font-semibold">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {employees.map((employee, idx) => (
                    <tr
                      key={employee._id}
                      className={`border-t border-border ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-muted/20'
                      } hover:bg-accent/5 transition-colors`}
                    >
                      <td className="px-6 py-4 font-medium text-foreground">
                        {employee.name}
                      </td>
                      <td className="px-6 py-4 text-foreground/70">{employee.role}</td>
                      <td className="px-6 py-4 text-right text-foreground/70">
                        R$ {employee.salary.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 text-foreground/70">
                        {employee.workSchedule}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span
                          className={`px-3 py-1 rounded-full text-sm font-medium ${
                            employee.status === 'ativo'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-700'
                          }`}
                        >
                          {employee.status === 'ativo' ? 'Ativo' : 'Inativo'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleOpenDialog(employee)}
                            className="p-2 hover:bg-accent/20 rounded-lg transition-colors text-accent"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDelete(employee._id!)}
                            className="p-2 hover:bg-destructive/20 rounded-lg transition-colors text-destructive"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      {/* Dialog para criar/editar funcionário */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="bg-card border-2 border-accent">
          <DialogHeader>
            <DialogTitle className="text-primary">
              {editingId ? 'Editar Funcionário' : 'Novo Funcionário'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Nome *
              </label>
              <Input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Cargo
                </label>
                <Input
                  type="text"
                  value={formData.role}
                  onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Salário
                </label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.salary}
                  onChange={(e) =>
                    setFormData({ ...formData, salary: Number(e.target.value) })
                  }
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Horário de Trabalho
              </label>
              <Input
                type="text"
                value={formData.workSchedule}
                onChange={(e) =>
                  setFormData({ ...formData, workSchedule: e.target.value })
                }
                placeholder="Ex: 08:00 - 17:00"
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    status: e.target.value as 'ativo' | 'inativo',
                  })
                }
                className="w-full px-3 py-2 border-2 border-accent/30 focus:border-accent rounded-lg bg-white text-foreground"
              >
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo</option>
              </select>
            </div>
            <div className="flex gap-3 justify-end pt-4">
              <Button
                type="button"
                onClick={() => setOpenDialog(false)}
                variant="outline"
                className="border-2 border-accent text-accent hover:bg-accent/10"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="bg-accent text-accent-foreground hover:bg-accent/90"
              >
                {editingId ? 'Atualizar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
