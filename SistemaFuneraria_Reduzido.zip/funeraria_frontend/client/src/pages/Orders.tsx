import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { Order, orderAPI, Product, productAPI, Service, serviceAPI, Employee, employeeAPI } from '@/lib/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Trash2, Edit2, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Order>({
    clientName: '',
    products: [],
    services: [],
    employee: '',
    totalPrice: 0,
    status: 'aberta',
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [ordersRes, productsRes, servicesRes, employeesRes] = await Promise.all([
        orderAPI.getAll(),
        productAPI.getAll(),
        serviceAPI.getAll(),
        employeeAPI.getAll(),
      ]);
      setOrders(ordersRes.data);
      setProducts(productsRes.data);
      setServices(servicesRes.data);
      setEmployees(employeesRes.data);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar dados');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (order?: Order) => {
    if (order) {
      setEditingId(order._id || null);
      setFormData(order);
    } else {
      setEditingId(null);
      setFormData({
        clientName: '',
        products: [],
        services: [],
        employee: '',
        totalPrice: 0,
        status: 'aberta',
      });
    }
    setOpenDialog(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await orderAPI.update(editingId, formData);
        toast.success('Pedido atualizado com sucesso');
      } else {
        await orderAPI.create(formData);
        toast.success('Pedido criado com sucesso');
      }
      setOpenDialog(false);
      fetchData();
    } catch (err) {
      toast.error('Erro ao salvar pedido');
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja deletar este pedido?')) {
      try {
        await orderAPI.delete(id);
        toast.success('Pedido deletado com sucesso');
        fetchData();
      } catch (err) {
        toast.error('Erro ao deletar pedido');
        console.error(err);
      }
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'aberta':
        return 'bg-blue-100 text-blue-700';
      case 'concluida':
        return 'bg-green-100 text-green-700';
      case 'cancelada':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <Layout currentPage="/orders">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="display text-3xl font-bold text-primary">Pedidos</h1>
            <p className="text-foreground/70 mt-1">Gerencie os pedidos dos clientes</p>
          </div>
          <Button
            onClick={() => handleOpenDialog()}
            className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
          >
            <Plus size={20} />
            Novo Pedido
          </Button>
        </div>

        {error && (
          <div className="bg-destructive/10 border-2 border-destructive text-destructive p-4 rounded-lg">
            {error}
          </div>
        )}

        {/* Orders Table */}
        <Card className="border-2 border-accent/30 overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-foreground/60">Carregando pedidos...</div>
          ) : orders.length === 0 ? (
            <div className="p-8 text-center text-foreground/60">
              Nenhum pedido cadastrado
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-primary text-primary-foreground">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Cliente</th>
                    <th className="px-6 py-4 text-left font-semibold">Funcionário</th>
                    <th className="px-6 py-4 text-right font-semibold">Total</th>
                    <th className="px-6 py-4 text-center font-semibold">Status</th>
                    <th className="px-6 py-4 text-center font-semibold">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order, idx) => {
                    const employee = employees.find(e => e._id === order.employee);
                    return (
                      <tr
                        key={order._id}
                        className={`border-t border-border ${
                          idx % 2 === 0 ? 'bg-white' : 'bg-muted/20'
                        } hover:bg-accent/5 transition-colors`}
                      >
                        <td className="px-6 py-4 font-medium text-foreground">
                          {order.clientName}
                        </td>
                        <td className="px-6 py-4 text-foreground/70">
                          {employee?.name || 'N/A'}
                        </td>
                        <td className="px-6 py-4 text-right text-foreground/70">
                          R$ {order.totalPrice.toFixed(2)}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span
                            className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(
                              order.status
                            )}`}
                          >
                            {order.status === 'aberta'
                              ? 'Aberta'
                              : order.status === 'concluida'
                              ? 'Concluída'
                              : 'Cancelada'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center justify-center gap-2">
                            <button
                              onClick={() => handleOpenDialog(order)}
                              className="p-2 hover:bg-accent/20 rounded-lg transition-colors text-accent"
                            >
                              <Edit2 size={18} />
                            </button>
                            <button
                              onClick={() => handleDelete(order._id!)}
                              className="p-2 hover:bg-destructive/20 rounded-lg transition-colors text-destructive"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      {/* Dialog para criar/editar pedido */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="bg-card border-2 border-accent max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-primary">
              {editingId ? 'Editar Pedido' : 'Novo Pedido'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Nome do Cliente *
              </label>
              <Input
                type="text"
                value={formData.clientName}
                onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
                required
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Funcionário Responsável
              </label>
              <select
                value={formData.employee}
                onChange={(e) => setFormData({ ...formData, employee: e.target.value })}
                className="w-full px-3 py-2 border-2 border-accent/30 focus:border-accent rounded-lg bg-white text-foreground"
              >
                <option value="">Selecione um funcionário</option>
                {employees.map((emp) => (
                  <option key={emp._id} value={emp._id}>
                    {emp.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Preço Total
              </label>
              <Input
                type="number"
                step="0.01"
                value={formData.totalPrice}
                onChange={(e) =>
                  setFormData({ ...formData, totalPrice: Number(e.target.value) })
                }
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    status: e.target.value as 'aberta' | 'concluida' | 'cancelada',
                  })
                }
                className="w-full px-3 py-2 border-2 border-accent/30 focus:border-accent rounded-lg bg-white text-foreground"
              >
                <option value="aberta">Aberta</option>
                <option value="concluida">Concluída</option>
                <option value="cancelada">Cancelada</option>
              </select>
            </div>

            <div className="flex gap-3 justify-end pt-4">
              <Button
                type="button"
                onClick={() => setOpenDialog(false)}
                variant="outline"
                className="border-2 border-accent text-accent hover:bg-accent/10"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="bg-accent text-accent-foreground hover:bg-accent/90"
              >
                {editingId ? 'Atualizar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
