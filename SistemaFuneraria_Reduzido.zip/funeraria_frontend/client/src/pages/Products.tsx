import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { Product, productAPI } from '@/lib/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Trash2, Edit2, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Product>({
    name: '',
    category: '',
    quantity: 0,
    costPrice: 0,
    sellPrice: 0,
    supplier: '',
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await productAPI.getAll();
      setProducts(res.data);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar produtos');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (product?: Product) => {
    if (product) {
      setEditingId(product._id || null);
      setFormData(product);
    } else {
      setEditingId(null);
      setFormData({
        name: '',
        category: '',
        quantity: 0,
        costPrice: 0,
        sellPrice: 0,
        supplier: '',
      });
    }
    setOpenDialog(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await productAPI.update(editingId, formData);
        toast.success('Produto atualizado com sucesso');
      } else {
        await productAPI.create(formData);
        toast.success('Produto criado com sucesso');
      }
      setOpenDialog(false);
      fetchProducts();
    } catch (err) {
      toast.error('Erro ao salvar produto');
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja deletar este produto?')) {
      try {
        await productAPI.delete(id);
        toast.success('Produto deletado com sucesso');
        fetchProducts();
      } catch (err) {
        toast.error('Erro ao deletar produto');
        console.error(err);
      }
    }
  };

  return (
    <Layout currentPage="/products">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="display text-3xl font-bold text-primary">Produtos</h1>
            <p className="text-foreground/70 mt-1">Gerencie o inventário de produtos</p>
          </div>
          <Button
            onClick={() => handleOpenDialog()}
            className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
          >
            <Plus size={20} />
            Novo Produto
          </Button>
        </div>

        {error && (
          <div className="bg-destructive/10 border-2 border-destructive text-destructive p-4 rounded-lg">
            {error}
          </div>
        )}

        {/* Products Table */}
        <Card className="border-2 border-accent/30 overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-foreground/60">Carregando produtos...</div>
          ) : products.length === 0 ? (
            <div className="p-8 text-center text-foreground/60">
              Nenhum produto cadastrado
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-primary text-primary-foreground">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Nome</th>
                    <th className="px-6 py-4 text-left font-semibold">Categoria</th>
                    <th className="px-6 py-4 text-center font-semibold">Quantidade</th>
                    <th className="px-6 py-4 text-right font-semibold">Preço Custo</th>
                    <th className="px-6 py-4 text-right font-semibold">Preço Venda</th>
                    <th className="px-6 py-4 text-left font-semibold">Fornecedor</th>
                    <th className="px-6 py-4 text-center font-semibold">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product, idx) => (
                    <tr
                      key={product._id}
                      className={`border-t border-border ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-muted/20'
                      } hover:bg-accent/5 transition-colors`}
                    >
                      <td className="px-6 py-4 font-medium text-foreground">
                        {product.name}
                      </td>
                      <td className="px-6 py-4 text-foreground/70">{product.category}</td>
                      <td className="px-6 py-4 text-center text-foreground/70">
                        {product.quantity}
                      </td>
                      <td className="px-6 py-4 text-right text-foreground/70">
                        R$ {product.costPrice.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 text-right text-foreground/70">
                        R$ {product.sellPrice.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 text-foreground/70">{product.supplier}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleOpenDialog(product)}
                            className="p-2 hover:bg-accent/20 rounded-lg transition-colors text-accent"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDelete(product._id!)}
                            className="p-2 hover:bg-destructive/20 rounded-lg transition-colors text-destructive"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      {/* Dialog para criar/editar produto */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="bg-card border-2 border-accent">
          <DialogHeader>
            <DialogTitle className="text-primary">
              {editingId ? 'Editar Produto' : 'Novo Produto'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Nome *
              </label>
              <Input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Categoria
              </label>
              <Input
                type="text"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Quantidade
                </label>
                <Input
                  type="number"
                  value={formData.quantity}
                  onChange={(e) =>
                    setFormData({ ...formData, quantity: Number(e.target.value) })
                  }
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Preço Custo
                </label>
                <Input
                  type="number"
                  step="0.01"
value={formData.costPrice}
              onChange={(e) =>
                setFormData({ ...formData, costPrice: parseFloat(e.target.value.replace(',', '.')) })
              }
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Preço Venda
                </label>
                <Input
                  type="number"
                  step="0.01"
value={formData.sellPrice}
              onChange={(e) =>
                setFormData({ ...formData, sellPrice: parseFloat(e.target.value.replace(',', '.')) })
              }
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Fornecedor
                </label>
                <Input
                  type="text"
                  value={formData.supplier}
                  onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
            </div>
            <div className="flex gap-3 justify-end pt-4">
              <Button
                type="button"
                onClick={() => setOpenDialog(false)}
                variant="outline"
                className="border-2 border-accent text-accent hover:bg-accent/10"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="bg-accent text-accent-foreground hover:bg-accent/90"
              >
                {editingId ? 'Atualizar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
