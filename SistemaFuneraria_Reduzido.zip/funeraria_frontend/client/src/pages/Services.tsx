import { useEffect, useState } from 'react';
import Layout from '@/components/Layout';
import { Service, serviceAPI } from '@/lib/api';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Trash2, Edit2, Plus } from 'lucide-react';
import { toast } from 'sonner';

export default function Services() {
  const [services, setServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Service>({
    name: '',
    price: 0,
    estimatedTime: '',
    responsibleRole: '',
  });

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      setLoading(true);
      const res = await serviceAPI.getAll();
      setServices(res.data);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar serviços');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (service?: Service) => {
    if (service) {
      setEditingId(service._id || null);
      setFormData(service);
    } else {
      setEditingId(null);
      setFormData({
        name: '',
        price: 0,
        estimatedTime: '',
        responsibleRole: '',
      });
    }
    setOpenDialog(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await serviceAPI.update(editingId, formData);
        toast.success('Serviço atualizado com sucesso');
      } else {
        await serviceAPI.create(formData);
        toast.success('Serviço criado com sucesso');
      }
      setOpenDialog(false);
      fetchServices();
    } catch (err) {
      toast.error('Erro ao salvar serviço');
      console.error(err);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja deletar este serviço?')) {
      try {
        await serviceAPI.delete(id);
        toast.success('Serviço deletado com sucesso');
        fetchServices();
      } catch (err) {
        toast.error('Erro ao deletar serviço');
        console.error(err);
      }
    }
  };

  return (
    <Layout currentPage="/services">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="display text-3xl font-bold text-primary">Serviços</h1>
            <p className="text-foreground/70 mt-1">Gerencie os serviços oferecidos</p>
          </div>
          <Button
            onClick={() => handleOpenDialog()}
            className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
          >
            <Plus size={20} />
            Novo Serviço
          </Button>
        </div>

        {error && (
          <div className="bg-destructive/10 border-2 border-destructive text-destructive p-4 rounded-lg">
            {error}
          </div>
        )}

        {/* Services Table */}
        <Card className="border-2 border-accent/30 overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-foreground/60">Carregando serviços...</div>
          ) : services.length === 0 ? (
            <div className="p-8 text-center text-foreground/60">
              Nenhum serviço cadastrado
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-primary text-primary-foreground">
                  <tr>
                    <th className="px-6 py-4 text-left font-semibold">Nome</th>
                    <th className="px-6 py-4 text-right font-semibold">Preço</th>
                    <th className="px-6 py-4 text-left font-semibold">Tempo Estimado</th>
                    <th className="px-6 py-4 text-left font-semibold">Cargo Responsável</th>
                    <th className="px-6 py-4 text-center font-semibold">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {services.map((service, idx) => (
                    <tr
                      key={service._id}
                      className={`border-t border-border ${
                        idx % 2 === 0 ? 'bg-white' : 'bg-muted/20'
                      } hover:bg-accent/5 transition-colors`}
                    >
                      <td className="px-6 py-4 font-medium text-foreground">
                        {service.name}
                      </td>
                      <td className="px-6 py-4 text-right text-foreground/70">
                        R$ {service.price.toFixed(2)}
                      </td>
                      <td className="px-6 py-4 text-foreground/70">
                        {service.estimatedTime}
                      </td>
                      <td className="px-6 py-4 text-foreground/70">
                        {service.responsibleRole}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleOpenDialog(service)}
                            className="p-2 hover:bg-accent/20 rounded-lg transition-colors text-accent"
                          >
                            <Edit2 size={18} />
                          </button>
                          <button
                            onClick={() => handleDelete(service._id!)}
                            className="p-2 hover:bg-destructive/20 rounded-lg transition-colors text-destructive"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>

      {/* Dialog para criar/editar serviço */}
      <Dialog open={openDialog} onOpenChange={setOpenDialog}>
        <DialogContent className="bg-card border-2 border-accent">
          <DialogHeader>
            <DialogTitle className="text-primary">
              {editingId ? 'Editar Serviço' : 'Novo Serviço'}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Nome *
              </label>
              <Input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Preço
                </label>
                <Input
                  type="number"
                  step="0.01"
                  value={formData.price}
                  onChange={(e) =>
                    setFormData({ ...formData, price: Number(e.target.value) })
                  }
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">
                  Tempo Estimado
                </label>
                <Input
                  type="text"
                  value={formData.estimatedTime}
                  onChange={(e) =>
                    setFormData({ ...formData, estimatedTime: e.target.value })
                  }
                  placeholder="Ex: 2 horas"
                  className="border-2 border-accent/30 focus:border-accent"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1">
                Cargo Responsável
              </label>
              <Input
                type="text"
                value={formData.responsibleRole}
                onChange={(e) =>
                  setFormData({ ...formData, responsibleRole: e.target.value })
                }
                className="border-2 border-accent/30 focus:border-accent"
              />
            </div>
            <div className="flex gap-3 justify-end pt-4">
              <Button
                type="button"
                onClick={() => setOpenDialog(false)}
                variant="outline"
                className="border-2 border-accent text-accent hover:bg-accent/10"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="bg-accent text-accent-foreground hover:bg-accent/90"
              >
                {editingId ? 'Atualizar' : 'Criar'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
